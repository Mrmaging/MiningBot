require("dotenv").config();
const express = require("express");
const fs = require("fs");
const cors = require("cors");
const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

const dbFile = "./db.json";
let db = { users: [] };

// Load DB
if (fs.existsSync(dbFile)) {
  db = JSON.parse(fs.readFileSync(dbFile, "utf-8"));
}

// Save DB
function saveDB() {
  fs.writeFileSync(dbFile, JSON.stringify(db, null, 2));
}

// Register
app.post("/register", (req, res) => {
  const { telegram_id, username, lang } = req.body;
  let user = db.users.find(u => u.telegram_id === telegram_id);
  if (!user) {
    user = {
      id: db.users.length + 1,
      telegram_id,
      username,
      lang,
      current_balance: 0,
      total_mined: 0
    };
    db.users.push(user);
    saveDB();
  }
  res.json({ id: user.id });
});

// Get balance
app.get("/balance/:id", (req, res) => {
  const user = db.users.find(u => u.telegram_id === req.params.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({
    current_balance: user.current_balance,
    total_mined: user.total_mined
  });
});

// Withdraw request (simulate)
app.post("/withdraw", (req, res) => {
  const { telegram_id, amount } = req.body;
  const user = db.users.find(u => u.telegram_id === telegram_id);
  if (!user) return res.status(404).json({ error: "User not found" });
  if (user.current_balance < amount) {
    return res.status(400).json({ error: "Insufficient balance" });
  }
  user.current_balance -= amount;
  saveDB();
  res.json({ success: true, new_balance: user.current_balance });
});

// Admin login
app.post("/admin/login", (req, res) => {
  const { password } = req.body;
  if (password === process.env.ADMIN_PASSWORD) {
    res.json({ success: true });
  } else {
    res.status(401).json({ success: false, error: "Unauthorized" });
  }
});

// Admin update user balance
app.post("/admin/update", (req, res) => {
  const { telegram_id, amount } = req.body;
  const user = db.users.find(u => u.telegram_id === telegram_id);
  if (!user) return res.status(404).json({ error: "User not found" });
  user.current_balance = amount;
  saveDB();
  res.json({ success: true });
});

// Auto mining (simulated increase)
setInterval(() => {
  db.users.forEach(user => {
    user.current_balance += 0.01;
    user.total_mined += 0.01;
  });
  saveDB();
}, 300000); // every 5 minutes

app.listen(port, () => {
  console.log(`TON Miner backend running at http://localhost:${port}`);
});
